package com.abyss.aimbot;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CODE = 100;
    private Button toggleButton;
    private TextView statusText;
    private boolean isRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toggleButton = findViewById(R.id.toggleButton);
        statusText = findViewById(R.id.statusText);

        toggleButton.setOnClickListener(v -> {
            if (isRunning) {
                stopService(new Intent(this, AbyssService.class));
                isRunning = false;
                toggleButton.setText("▶ تشغيل");
                statusText.setText("⏹ متوقف");
                statusText.setTextColor(0xFFFF4444);
                Toast.makeText(this, "⟦ تم إيقاف أبيس ⟧", Toast.LENGTH_SHORT).show();
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
                    Toast.makeText(this, "⚠️ مطلوب صلاحية النافذة العائمة", Toast.LENGTH_LONG).show();
                    return;
                }
                MediaProjectionManager pm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                startActivityForResult(pm.createScreenCaptureIntent(), REQUEST_CODE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            Intent intent = new Intent(this, AbyssService.class);
            intent.putExtra("resultCode", resultCode);
            intent.putExtra("data", data);
            startService(intent);
            isRunning = true;
            toggleButton.setText("⏹ إيقاف");
            statusText.setText("✅ نشط");
            statusText.setTextColor(0xFF00FF41);
            Toast.makeText(this, "⟦ أبيس نشط ⟧", Toast.LENGTH_SHORT).show();
        }
    }
}