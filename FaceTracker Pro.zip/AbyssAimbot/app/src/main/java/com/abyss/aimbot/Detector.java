package com.abyss.aimbot;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.Log;
import org.tensorflow.lite.Interpreter;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

public class Detector {
    private static final String TAG = "Detector";
    private Interpreter interpreter;
    private int inputSize = 320;
    private float confidenceThreshold = 0.3f;

    public Detector(Context context) {
        try {
            InputStream modelStream = context.getAssets().open("model.tflite");
            byte[] modelBytes = new byte[modelStream.available()];
            modelStream.read(modelBytes);
            modelStream.close();
            interpreter = new Interpreter(modelBytes);
            Log.d(TAG, "✅ نموذج TFLite محمّل");
        } catch (Exception e) {
            Log.e(TAG, "⚠️ فشل تحميل النموذج: " + e.getMessage());
        }
    }

    public List<HeadPoint> detect(Bitmap bitmap) {
        List<HeadPoint> heads = new ArrayList<>();
        if (interpreter == null) return heads;

        Bitmap resized = Bitmap.createScaledBitmap(bitmap, inputSize, inputSize, true);
        ByteBuffer inputBuffer = convertBitmapToByteBuffer(resized);
        float[][][] output = new float[1][8400][85];
        interpreter.run(inputBuffer, output);

        float[][] detections = output[0];
        for (int i = 0; i < detections.length; i++) {
            float confidence = detections[i][4];
            if (confidence > confidenceThreshold) {
                float x = detections[i][0] / inputSize * bitmap.getWidth();
                float y = detections[i][1] / inputSize * bitmap.getHeight();
                float w = detections[i][2] / inputSize * bitmap.getWidth();
                float h = detections[i][3] / inputSize * bitmap.getHeight();
                int headX = (int) (x + w / 2);
                int headY = (int) (y + h * 0.12);
                heads.add(new HeadPoint(headX, headY, confidence));
            }
        }
        Log.d(TAG, "تم الكشف عن " + heads.size() + " رأس");
        return heads;
    }

    private ByteBuffer convertBitmapToByteBuffer(Bitmap bitmap) {
        ByteBuffer buffer = ByteBuffer.allocateDirect(1 * inputSize * inputSize * 3 * 4);
        buffer.order(ByteOrder.nativeOrder());
        int[] pixels = new int[inputSize * inputSize];
        bitmap.getPixels(pixels, 0, inputSize, 0, 0, inputSize, inputSize);
        for (int pixel : pixels) {
            buffer.putFloat(((pixel >> 16) & 0xFF) / 255.0f);
            buffer.putFloat(((pixel >> 8) & 0xFF) / 255.0f);
            buffer.putFloat((pixel & 0xFF) / 255.0f);
        }
        return buffer;
    }

    public static class HeadPoint {
        public int x, y;
        public float confidence;
        public HeadPoint(int x, int y, float confidence) {
            this.x = x;
            this.y = y;
            this.confidence = confidence;
        }
    }
}