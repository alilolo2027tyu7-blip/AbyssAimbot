package com.abyss.aimbot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.graphics.Path;
import android.os.Build;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;

public class TouchSimulator {
    private static final String TAG = "TouchSimulator";
    private AccessibilityService accessibilityService;
    private List<int[]> history = new ArrayList<>();

    public TouchSimulator(Context context) { }

    public void setAccessibilityService(AccessibilityService service) {
        this.accessibilityService = service;
    }

    public void tap(int x, int y) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && accessibilityService != null) {
            Path path = new Path();
            path.moveTo(x, y);
            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 1));
            accessibilityService.dispatchGesture(builder.build(), null, null);
            Log.d(TAG, "👆 لمس عند (" + x + ", " + y + ")");
        }
    }

    public void addHistory(int x, int y) {
        history.add(new int[]{x, y});
        if (history.size() > 5) history.remove(0);
    }

    public boolean hasHistory() {
        return history.size() >= 2;
    }

    public Detector.HeadPoint predict(Detector.HeadPoint current) {
        if (history.size() < 2) return current;
        int[] last = history.get(history.size() - 1);
        int[] prev = history.get(history.size() - 2);
        int dx = last[0] - prev[0];
        int dy = last[1] - prev[1];
        int predX = current.x + dx;
        int predY = current.y + dy;
        return new Detector.HeadPoint(predX, predY, current.confidence);
    }
}