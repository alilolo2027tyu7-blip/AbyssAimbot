package com.abyss.aimbot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public class AbyssService extends Service {
    private static final String TAG = "AbyssService";
    private static final String CHANNEL_ID = "abyss_channel";
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private Handler handler = new Handler();
    private boolean isRunning = true;
    private Detector detector;
    private TouchSimulator touchSimulator;
    private List<Long> reactionTimes = new ArrayList<>();

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(1, createNotification());
        detector = new Detector(this);
        touchSimulator = new TouchSimulator(this);
        Log.d(TAG, "أبيس يبدأ");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        int resultCode = intent.getIntExtra("resultCode", -1);
        Intent data = intent.getParcelableExtra("data");
        if (resultCode != -1 && data != null) {
            mediaProjection = ((MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE))
                    .getMediaProjection(resultCode, data);
            startCapture();
        }
        return START_STICKY;
    }

    private void startCapture() {
        int width = 720;
        int height = 1280;
        int density = 240;

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        imageReader.setOnImageAvailableListener(reader -> {
            Image image = reader.acquireLatestImage();
            if (image != null) {
                processImage(image);
                image.close();
            }
        }, handler);

        virtualDisplay = mediaProjection.createVirtualDisplay(
                "AbyssCapture",
                width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null, null
        );
        Log.d(TAG, "بدء التقاط الشاشة");
    }

    private void processImage(Image image) {
        if (!isRunning) return;
        long startTime = System.currentTimeMillis();

        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer();
        Bitmap bitmap = Bitmap.createBitmap(image.getWidth(), image.getHeight(), Bitmap.Config.ARGB_8888);
        bitmap.copyPixelsFromBuffer(buffer);

        List<Detector.HeadPoint> heads = detector.detect(bitmap);

        if (!heads.isEmpty()) {
            Detector.HeadPoint target = heads.get(0);
            if (touchSimulator.hasHistory()) {
                target = touchSimulator.predict(target);
            }
            touchSimulator.tap(target.x, target.y);
            touchSimulator.addHistory(target.x, target.y);

            long elapsed = System.currentTimeMillis() - startTime;
            reactionTimes.add(elapsed);
            if (reactionTimes.size() > 100) reactionTimes.remove(0);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Abyss Aimbot",
                    NotificationManager.IMPORTANCE_LOW
            );
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    private Notification createNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("⚡ أبيس نشط")
                .setContentText("جاري تحليل الشاشة...")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .build();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
        if (virtualDisplay != null) virtualDisplay.release();
        if (mediaProjection != null) mediaProjection.stop();
        if (imageReader != null) imageReader.close();
        Log.d(TAG, "أبيس يتوقف");
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}